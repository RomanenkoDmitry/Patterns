﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Builder
{
    class Guitar
    {
        private string model_name;
        private string country;  
        private string company;
        private int strings;
        private bool has_jack;

        public Guitar()
        {
            model_name = "Gibson Les Paul";
            country = "США";
            company = "Gibson";
            strings = 6;
            has_jack = true;
        }

        public void GetInfo()
        {
            Console.WriteLine("Модель: " + model_name);
            Console.WriteLine("Страна-производитель: " + country);
            Console.WriteLine("Компания: " + company);
            Console.WriteLine("Количество струн: " + strings);
            if (has_jack)
                Console.WriteLine("Используется jack-гнездо\n");
            else
                Console.WriteLine("Используется иное гнездо\n");
        }
        public string Model_name
        {
            get => model_name;
            set => model_name = value;
        }
        public string Country
        {
            get => country;
            set => country = value;
        }

        public string Company
        {
            get => company;
            set => company = value;
        }

        public int Strings
        {
            get => strings;
            set => strings = value;
        }

        public bool Jack
        {
            get => has_jack;
            set => has_jack = value;
        }
    }
}
