﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Builder
{
    class Models
    {
        public Models()
        {
            return;
        }

        public void GibsonLesPaul(GuitarBuilder builder)
        {
            builder.Reset();
        }

        public void IbanezSuperstrat(GuitarBuilder builder)
        {
            builder.Reset();
            builder.ModelNameInfo("Ibanez Superstrat JX-67");
            builder.CompanyInfo("Ibanez");
        }

        public void LTDExplorer(GuitarBuilder builder)
        {
            builder.Reset();
            builder.ModelNameInfo("LTD Explorer Destroyer Over9000");
            builder.CountryInfo("Япония");
            builder.CompanyInfo("ESP");
            builder.StringsInfo(7);
        }

        public void UralFromRussiaWithLove(GuitarBuilder builder)
        {
            builder.Reset();
            builder.ModelNameInfo("Урал МС 1980");
            builder.CountryInfo("Россия");
            builder.CompanyInfo("Урал");
            builder.JeckInfo(false);
        }
    }
}
