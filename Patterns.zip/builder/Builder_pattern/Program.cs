﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Builder
{
    class Program
    {
        static void Main(string[] args)
        {
            GuitarBuilder builder = new GuitarBuilder();
            Models model = new Models();

            model.GibsonLesPaul(builder);
            Guitar lespaul = builder.GuitarInfo();
            lespaul.GetInfo();

            model.IbanezSuperstrat(builder);
            Guitar superstrat = builder.GuitarInfo();
            superstrat.GetInfo();

            model.LTDExplorer(builder);
            Guitar explorer = builder.GuitarInfo();
            explorer.GetInfo();

            model.UralFromRussiaWithLove(builder);
            Guitar ural = builder.GuitarInfo();
            ural.GetInfo();

            Console.ReadKey();
        }
    }
}
