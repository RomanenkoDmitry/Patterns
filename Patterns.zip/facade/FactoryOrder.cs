﻿using System;
using System.Collections;
using abstractFactory.FactoryManagment;

namespace abstractFactory
{
    class FactoryOrder
    {
		ArrayList order = new ArrayList();

		public void Add(object guitar)
		{
			order.Add(guitar);
		}

		public void StartOrder() 
		{
			// подсчет количества электрогитар и акустик
			int countElectric = 0;
			int countAcoustic = 0;
			foreach (object obj in order)
			{
				if (obj is Electric) countElectric++;
				else if (obj is Acoustic) countAcoustic++;
			}

			// Если на складе осталось дерево только для одной акустики, закупается дополнительный материал
			if (countElectric >= 2 * countAcoustic)
			{
				// создаем только электрогитары
				foreach (object obj in order)
				{
					if (obj is Electric) (obj as Electric).FormCut();
				}
			}
			else
			{
				// Производим оба вида гитар
				foreach (object obj in order)
				{
					if (obj is Electric) (obj as Electric).FormCut();
					if (obj is Acoustic) (obj as Acoustic).DeckForm();
				}
			}
		}
	}
}
