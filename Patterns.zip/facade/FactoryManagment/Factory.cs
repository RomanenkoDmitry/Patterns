﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace abstractFactory.FactoryManagment
{
    public abstract class Factory
    {
        public abstract Electric CreateElectric();

        public abstract Acoustic CreateAcoustic();

        public abstract Strings CreateStrings();
    }
}
