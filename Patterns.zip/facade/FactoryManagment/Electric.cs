﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace abstractFactory.FactoryManagment
{
    public abstract class Electric
    {
        public abstract void WoodChoice();

        public abstract void FormCut();

        public abstract void MakePickups();
    }
}
