﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace abstractFactory.FactoryManagment
{
    public abstract class Acoustic
    {
        public abstract void DeckForm();

        public abstract void Coating();
    }
}
