﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace abstractFactory.FactoryManagment
{
    public abstract class Strings
    {

        public abstract void Size();
    }
}
