﻿using System;

namespace abstractFactory.FactoryManagment
{
    class Program
    {
		static void Main(string[] args)
		{
			Controller gguitar = new Controller(new Gibson.GibsonCorparation());

			gguitar.MakeOrder();

			Console.Read();
		}
	}
}
