﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace abstractFactory.Gibson
{
    public class LesPaul : FactoryManagment.Electric
    {
        public LesPaul()
        {
            Console.WriteLine("Creading every Les Paul with love");
        }

        public override void WoodChoice()
        {
            Console.WriteLine("Mahagony is the most musical tree");
        }

        public override void FormCut()
        {
            Console.WriteLine("The best gitar form in the world");
        }

        public override void MakePickups()
        {
            Console.WriteLine("Hambackers for the groove sound");
        }
    }
}
