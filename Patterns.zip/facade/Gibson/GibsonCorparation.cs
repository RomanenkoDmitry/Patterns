﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using abstractFactory.FactoryManagment;

namespace abstractFactory.Gibson
{
    public class GibsonCorparation : Factory
    {   
        public override Acoustic CreateAcoustic()
        {
            return new GibsonAcoustic();
        }
        public override Electric CreateElectric()
        {
            return new LesPaul();
        }

        public override Strings CreateStrings()
        {
            return new Elexir();
        }
    }
}
