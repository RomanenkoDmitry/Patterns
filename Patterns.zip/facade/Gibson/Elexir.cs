﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace abstractFactory.Gibson
{
    public class Elexir : FactoryManagment.Strings
    {
        public Elexir()
        {
            Console.WriteLine("Elixir is expensive high quality");
        }

        public override void Size()
        {
            Console.WriteLine("10-11 size");
        }
    }
}
