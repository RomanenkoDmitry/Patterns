﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace abstractFactory.Gibson
{
    public class GibsonAcoustic : FactoryManagment.Acoustic
    {
        public GibsonAcoustic()
        {
            Console.WriteLine("Creating the acoustic guitar for Gibson");
        }

        public override void DeckForm()
        {
            Console.WriteLine("Creating simmetric form");
        }

        public override void Coating()
        {
            Console.WriteLine("Matt coating");
        }
    }
}
