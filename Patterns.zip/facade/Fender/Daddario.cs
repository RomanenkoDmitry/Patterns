﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace abstractFactory.Fender
{
    public class Daddario : FactoryManagment.Strings
    {
        public Daddario()
        {
            Console.WriteLine("The best quality for this money!");
        }

        public override void Size()
        {
            Console.WriteLine("9-10 size");
        }
    }
}
