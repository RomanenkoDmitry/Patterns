﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using abstractFactory.FactoryManagment;

namespace abstractFactory.Fender
{
    public class FenderCompany: Factory
    {
        public override Acoustic CreateAcoustic()
        {
            return new FenderAcoustic();
        }
        public override Electric CreateElectric()
        {
            return new Stratocaster();
        }

        public override Strings CreateStrings()
        {
            return new Daddario();
        }
    }
}
