﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace abstractFactory.Fender
{
    public class FenderAcoustic : FactoryManagment.Acoustic
    {
        public FenderAcoustic()
        {
            Console.WriteLine("Start creating Fender Acoustic, babie!");
        }

        public override void DeckForm()
        {
            Console.WriteLine("It will be rock'n'roll form!");
        }

        public override void Coating()
        {
            Console.WriteLine("Varnish coating!");
        }
    }
}
