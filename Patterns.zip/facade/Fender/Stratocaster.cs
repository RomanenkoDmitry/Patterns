﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace abstractFactory.Fender
{
    public class Stratocaster : FactoryManagment.Electric
    {
        public Stratocaster()
        {
            Console.WriteLine("High sound and good form");
        }

        public override void  WoodChoice()
        {
            Console.WriteLine("Linden is the best choise (and cheap)!");
        }

        public override void  FormCut()
        {
            Console.WriteLine("Legendary stratocaster form!");
        }

        public override void MakePickups()
        {
            Console.WriteLine("Single pickups for the best clean sound!");
        }
    }
}
