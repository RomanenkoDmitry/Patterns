﻿using System;
using abstractFactory.FactoryManagment;

namespace abstractFactory
{
    public class Controller
    {
        Factory bildguitar;
        public Controller(Factory bildguitar)
        {
            this.bildguitar = bildguitar;
        }
        /// <summary>
        /// "Производство"
        /// </summary>
        public void CreateGuitar()
        {
            Acoustic acoustic = bildguitar.CreateAcoustic();
            Electric electric = bildguitar.CreateElectric();
            Strings strings = bildguitar.CreateStrings();

            acoustic.DeckForm();
            electric.WoodChoice();
            strings.Size();
        }

        public void MakeOrder() 
        {
            // Выполняем заказ
            Console.WriteLine("Закупаем необходимое дерево:");
            FactoryOrder ord = new FactoryOrder();
            ord.Add(bildguitar.CreateElectric());
            ord.Add(bildguitar.CreateElectric());
            ord.Add(bildguitar.CreateAcoustic());

            Console.WriteLine("");
            Console.WriteLine("Обрабатываем дерево для электрогитар:");
            ord.StartOrder();

            // добавляем еще одного война
            Console.WriteLine("");
            Console.WriteLine("Обрабатываем дерево для акустики :");
            ord.Add(bildguitar.CreateAcoustic());

            Console.WriteLine("");
            Console.WriteLine("Полностью выполняем условие заказа:");
            ord.StartOrder();
        }
    }
}