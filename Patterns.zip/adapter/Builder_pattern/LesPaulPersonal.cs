﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adapter
{
    class LesPaulPersonal
    {
        private string model_name;
        private string country;
        private string company;
        private int strings;
        private bool has_jack;
        private string microphone;

        public LesPaulPersonal()
        {
            model_name = "Gibson Les Paul Personal";
            country = "США";
            company = "Gibson";
            strings = 6;
            has_jack = true;
            microphone = "У данной модели имеется разъем для микрофона";
        }

        public void GetInfo()
        {
            Console.WriteLine("Модель: " + model_name);
            Console.WriteLine("Страна-производитель: " + country);
            Console.WriteLine("Компания: " + company);
            Console.WriteLine("Количество струн: " + strings);
            if (has_jack)
                Console.WriteLine("Используется jack-гнездо\n");
            else
                Console.WriteLine("Используется иное гнездо\n");
            Console.WriteLine(microphone);
        }
        public string Model_name
        {
            get => model_name;
            set => model_name = value;
        }
        public string Country
        {
            get => country;
            set => country = value;
        }

        public string Company
        {
            get => company;
            set => company = value;
        }

        public int Strings
        {
            get => strings;
            set => strings = value;
        }

        public bool Jack
        {
            get => has_jack;
            set => has_jack = value;
        }

        public string Microphone
        {
            get => microphone;
            set => microphone = value;
        }
    }
}