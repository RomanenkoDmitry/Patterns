﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adapter
{
    interface GuitarBuilderInterface
    {
        void Reset();
        void ModelNameInfo(string model_name);
        void CountryInfo(string country);
        void CompanyInfo(string company);
        void StringsInfo(int strings);
        void JeckInfo(bool set);
    }
}
