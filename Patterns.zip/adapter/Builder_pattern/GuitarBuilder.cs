﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adapter
{
    class GuitarBuilder : GuitarBuilderInterface
    {
        private Guitar guitar;

        public void Reset()
        {
            guitar = new Guitar();
        }
        public void ModelNameInfo(string model_name)
        {
            guitar.Model_name = model_name;
        }
        public void CountryInfo(string country)
        {
            guitar.Country = country;
        }

        public void CompanyInfo(string company)
        {
            guitar.Company = company;
        }

        public void StringsInfo(int strings)
        {
            guitar.Strings = strings;
        }

        public void JeckInfo(bool set)
        {
            guitar.Jack = set;
        }

        public Guitar GuitarInfo()
        {
            return guitar;
        }
    }
}
