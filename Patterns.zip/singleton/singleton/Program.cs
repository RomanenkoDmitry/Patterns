﻿using System;

namespace Singleton
{
	class Program
	{
		[STAThread]
		static void Main(string[] args)
		{
			FavoriteGuitar explorer = FavoriteGuitar.Instance();

			// Повторим создание. Instance вернет уже созданный объект.
			FavoriteGuitar explorer1 = FavoriteGuitar.Instance();

			Console.Read();
		}
	}
}

