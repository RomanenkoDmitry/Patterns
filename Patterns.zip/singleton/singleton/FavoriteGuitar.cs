﻿using System;

namespace Singleton
{
	/// <summary>
	/// Класс, описывающий любимую гитару
	/// </summary>
	public class FavoriteGuitar
	{
		/// <summary>
		/// </summary>
		static FavoriteGuitar guitar;

		protected FavoriteGuitar()
		{
			Console.WriteLine("Любимая гитара выбрана");
		}

		public static FavoriteGuitar Instance()
		{
			if (guitar == null)
			{
				guitar = new FavoriteGuitar();
			}
			else
			{
				Console.WriteLine("Old but gold");
			}
			return guitar;
		}
	}
}
