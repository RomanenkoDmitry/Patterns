﻿using System;
using System.Collections.Generic;
using System.Text;

namespace decorator_pedalbord
{
    class Pedalboard : IPedalboard
    {
        public void ShowInfo()
        {
            Console.Write("Комбоусилитель");
        }
    }
}
