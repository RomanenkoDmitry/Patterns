﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace decorator_pedalbord
{
    class DelayDec : AbsDec
    {
        public DelayDec(IPedalboard obj)
        {
            this.obj = obj;
        }

        public override void ShowInfo()
        {
            obj.ShowInfo();
            Console.Write("----> Педаль дилея");
        }
    }
}
