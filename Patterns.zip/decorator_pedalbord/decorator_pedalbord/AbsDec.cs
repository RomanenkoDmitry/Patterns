﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace decorator_pedalbord 
{
    abstract class AbsDec : IPedalboard
    {
        public IPedalboard obj;

        public AbsDec(IPedalboard obj = null)
        {
            this.obj = obj;
        }

        public virtual void ShowInfo()
        {
            return;
        }
    }
}