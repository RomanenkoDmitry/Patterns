﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace decorator_pedalbord
{
    class PhaserDec : AbsDec
    {
        public PhaserDec(IPedalboard obj)
        {
            this.obj = obj;
        }

        public override void ShowInfo()
        {
            obj.ShowInfo();
            Console.Write("----> Фейзер");
        }
    }
}
