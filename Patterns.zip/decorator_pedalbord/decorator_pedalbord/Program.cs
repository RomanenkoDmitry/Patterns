﻿using System;

namespace decorator_pedalbord
{
    class Program
    {
        static void Show(IPedalboard pedalboard)
        {
            Console.WriteLine("Цепь имеет следующий вид");
            pedalboard.ShowInfo();
            Console.WriteLine();
        }
        static void Main(string[] args)
        {
            IPedalboard pedalboard = new Pedalboard();
            Show(pedalboard);
            Console.WriteLine();

            pedalboard = new DistortionDec(pedalboard);
            Show(pedalboard);
            Console.WriteLine();

            pedalboard = new DelayDec(pedalboard);
            Show(pedalboard);
            Console.WriteLine();

            pedalboard = new PhaserDec(pedalboard);
            Show(pedalboard);
            Console.WriteLine();

            pedalboard = new CompressorDec(pedalboard);
            Show(pedalboard);
            Console.WriteLine();

            Console.ReadKey();
        }
    }
}
