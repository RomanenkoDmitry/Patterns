﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Flyweight
{ 
    abstract class Playlist
    {
        protected int songs; // количество песен

        public abstract void Build(int songsduration, int authorscount);
    }
    class Album : Playlist
    {
        public Album()
        {
            songs = 13;
        }

        public override void Build(int songsduration, int authorscount)
        {
            Console.WriteLine("Составлен плейлист из альбома, продолжительностью {0} минут с числом исполнителей, равным {1}", songsduration, authorscount);
        }
    }
    class EP : Playlist
    {
        public EP()
        {
            songs = 6;
        }

        public override void Build(int songsduration, int authorscount)
        {
            Console.WriteLine("Составлен плейлист из мини-альбома, продолжительностью {0} минут с числом исполнителей, равным {1}", songsduration, authorscount);
        }
    }

    class PlaylistMaking
    {
        Dictionary<string, Playlist> playlist = new Dictionary<string, Playlist>();
        public PlaylistMaking()
        {
            playlist.Add("Album song", new Album());
            playlist.Add("EP song", new EP());
        }

        public Playlist GetTrain(string key)
        {
            if (playlist.ContainsKey(key))
                return playlist[key];
            else
                return null;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            int songsduration = 5;
            int authorscount = 1;

            PlaylistMaking pl = new PlaylistMaking();
            for (int i = 0; i < 5; i++)
            {
                Playlist album = pl.GetTrain("Album song");
                if (album != null)
                    album.Build(songsduration, authorscount);
                songsduration += 5;
                authorscount += 1;
            }

            for (int i = 0; i < 5; i++)
            {
                Playlist ep = pl.GetTrain("EP song");
                if (ep != null)
                    ep.Build(songsduration, authorscount);
                songsduration += 5;
                authorscount += 1;
            }

            Console.Read();
        }
    }
}
