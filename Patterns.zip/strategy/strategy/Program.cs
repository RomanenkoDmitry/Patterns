﻿using System;
using Strategy.Strategies;

namespace Strategy
{
	class Program
	{
		[STAThread]
		static void Main(string[] args)
		{
			Console.WriteLine("Порядок действий сотрудника Компании Fender: ");

			FenderConstructor fender = new FenderConstructor(new BildGuitar());

			fender.DoSometring();

			fender.Strategy = new EstimateGuitar();

			fender.DoSometring();

			fender.Strategy = new CheckGuitar();

			fender.DoSometring();

            Console.WriteLine("Порядок действий сотрудника Компании Gibson: ");

			GibsonConstructor gibson = new GibsonConstructor(new BildGuitar());
			gibson.DoSometring();

			gibson.Strategy = new CheckGuitar();

			gibson.DoSometring();


			Console.Read();
		}
	}
}
