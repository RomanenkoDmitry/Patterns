﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Strategy.Strategies
{
    public class CheckGuitar : Strategy
    {
        public override void DoIt()
        {
            Console.WriteLine("Проверка инструмента");
        }

    }
}
