﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Strategy.Strategies
{
    public class BildGuitar : Strategy
    {
        public override void DoIt()
        {
            Console.WriteLine("Сборка инструмента");
        }

    }
}
