﻿using System;

namespace Strategy.Strategies
{
	/// <summary>
	/// Абстрактный базовый класс стратегий.
	/// </summary>
	public abstract class Strategy
	{
		public abstract void DoIt();
	}
}
