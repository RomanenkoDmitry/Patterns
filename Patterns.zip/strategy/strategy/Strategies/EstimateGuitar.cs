﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Strategy.Strategies
{
    public class EstimateGuitar : Strategy
    {
        public override void DoIt()
        {
            Console.WriteLine("Оценка инструмента");
        }

    }
}
