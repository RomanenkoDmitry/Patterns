﻿using System;
using Strategy.Strategies;

namespace Strategy
{
	public class FenderConstructor
	{
		Strategy.Strategies.Strategy work;
		public FenderConstructor(Strategy.Strategies.Strategy work)
		{
			this.work = work;
		}

		public Strategy.Strategies.Strategy Strategy
		{
			get { return work; }
			set { work = value; }
		}

		/// Выполнение текущего действия
		public void DoSometring()
		{
			work.DoIt();
		}
	}
}
