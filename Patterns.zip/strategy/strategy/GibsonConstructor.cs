﻿using System;
using Strategy.Strategies;

namespace Strategy
{
	public class GibsonConstructor
	{
		Strategy.Strategies.Strategy work;
		public GibsonConstructor(Strategy.Strategies.Strategy work)
		{
			this.work = work;
		}

		public Strategy.Strategies.Strategy Strategy
		{
			get { return work; }
			set { work = value; }
		}

		/// Выполнение текущего действия
		public void DoSometring()
		{
			work.DoIt();
		}
	}
}