﻿using System;

namespace AbstractFactory.Humans
{
    /// <summary>
    /// Класс, описывающий функциональное поведение боевого юнита расы людей
    /// </summary>
    public class Paladin:BaseManagement.Warrior
    {
        public Paladin()
        {
            Console.WriteLine("Готов служить, милорд...");
        }

        /// <summary>
        /// Метод, реализующий применение заклинаний паладином
        /// </summary>
        public override void Cast()
        {
            Console.WriteLine("Благословляю тебя...");
        }

        /// <summary>
        /// Метод, реализующий рукопашную атаку паладина
        /// </summary>
        public override void HandToHand()
        {
            Console.WriteLine("Грешники, ко мне!");
        }
    }
}
