﻿using System;

namespace AbstractFactory.Humans
{
    /// <summary>
    /// Класс, описывающий функциональное поведение рабочего расы Люди.
    /// </summary>
    public class Worker:BaseManagement.Producer
    {
        public Worker()
        {
            Console.WriteLine("Опять работать...");
        }

        /// <summary>
        /// Метод, реализующий добычу золота рабочим
        /// </summary>
        public override void MiningGold()
        {
            Console.WriteLine("Где копать?");
        }

        /// <summary>
        /// Метод, реализующий рубку леса рабочим
        /// </summary>
        public override void FellTrees()
        {
            Console.WriteLine("В Сахаре тоже когда-то лес был...");
        }

        /// <summary>
        /// Метод, реализующий постройку зданий рабочим
        /// </summary>
        public override void Build()
        {
            Console.WriteLine("Стоит вроде...");
        }
    }
}
