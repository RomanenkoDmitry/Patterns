﻿using System;
using AbstractFactory.BaseManagement;

namespace AbstractFactory.Humans
{
    /// <summary>
    /// Класс, описывающий методы создания типовых игровых юнитов
    /// для расы Люди.
    /// </summary>
    public class HumanFactory : RaceFactory
    {
        /// <summary>
        /// Создание рабочего (юнит, производящий ресурсы для расы Люди)
        /// </summary>
        /// <returns>Ссылка на рабочего, приведенная к абстрактному классу Producer</returns>
        public override Producer CreateProducer()
        {
            return new Worker();
        }

        /// <summary>
        /// Создание эльфа-лучника (стрелковый юнит расы Люди)
        /// </summary>
        /// <returns>Ссылка на эльфа, приведенная к абстрактному классу Shooter</returns>
        public override Shooter CreateShooter()
        {
            return new Elf();
        }

        /// <summary>
        /// Создание паладина (боевой юнит расы Люди)
        /// </summary>
        /// <returns>Ссылка на паладина, приведенная к абстрактному классу Warrior</returns>
        public override Warrior CreateWarrior()
        {
            return new Paladin();
        }
    }
}
