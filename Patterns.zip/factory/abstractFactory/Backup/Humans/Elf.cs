﻿using System;

namespace AbstractFactory.Humans
{
    /// <summary>
    /// Класс, описывающий функциональное поведение стрелка-разведчика расы людей
    /// </summary>
    public class Elf : BaseManagement.Shooter
    {
        public Elf()
        {
            Console.WriteLine("Да, Господин...");
        }

        /// <summary>
        /// Метод, реализующий стрельбу из лука применительно к юниту эльф
        /// </summary>
        public override void Shoot()
        {
            Console.WriteLine("Белке в глаз!");
        }

        /// <summary>
        /// Метод, реализующий разведку местности применительно к юниту эльф
        /// </summary>
        public override void Reconnoitre()
        {
            Console.WriteLine("Уже иду...");
        }
    }
}
