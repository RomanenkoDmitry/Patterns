﻿using System;

namespace AbstractFactory.BaseManagement
{
    /// <summary>
    /// Абстрактный базовый класс, описывающий функциональное поведение стрелка 
    /// произвольной игровой расы.
    /// </summary>
    public abstract class Shooter
    {
        /// <summary>
        /// Метод, описывающий стрельбу
        /// </summary>
        public abstract void Shoot();

        /// <summary>
        /// Метод, описывающий разведку местности
        /// </summary>
        public abstract void Reconnoitre();
    }
}
