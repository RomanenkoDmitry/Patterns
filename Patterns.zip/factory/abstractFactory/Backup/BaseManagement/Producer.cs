﻿using System;

namespace AbstractFactory.BaseManagement
{
    /// <summary>
    /// Абстрактный базовый класс, описывающий функциональное поведение рабочего 
    /// произвольной игровой расы.
    /// </summary>
    public abstract class Producer
    {
        /// <summary>
        /// Метод, описывающий добычу золота
        /// </summary>
        public abstract void MiningGold();
        
        /// <summary>
        /// Метод, описывающий рубку леса
        /// </summary>
        public abstract void FellTrees();

        /// <summary>
        /// Метод, описывающий постройку зданий
        /// </summary>
        public abstract void Build();
    }
}
