﻿using System;

namespace AbstractFactory.BaseManagement
{
    /// <summary>
    /// Абстрактный базовый класс, описывающий функциональное поведение война 
    /// произвольной игровой расы.
    /// </summary>    
    public abstract class Warrior
    {
        /// <summary>
        /// Метод, описывающий применение заклинаний
        /// </summary>
        public abstract void Cast();

        /// <summary>
        /// Метод, описывающий рукопашную атаку
        /// </summary>
        public abstract void HandToHand();
    }
}
