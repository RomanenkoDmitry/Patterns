﻿using System;

namespace AbstractFactory.BaseManagement
{
    /// <summary>
    /// Абстрактный базовый класс, описывающий методы создания типовых игровых юнитов
    /// произвольной расы.
    /// </summary>
    public abstract class RaceFactory
    {
        /// <summary>
        /// Создание рабочего
        /// </summary>
        /// <returns>Абстрактный рабочий</returns>
        public abstract Producer CreateProducer();

        /// <summary>
        /// Создание стрелка
        /// </summary>
        /// <returns>Абстрактный стрелок</returns>
        public abstract Shooter CreateShooter();

        /// <summary>
        /// Создание война
        /// </summary>
        /// <returns>Абстрактный воин</returns>
        public abstract Warrior CreateWarrior();
    }
}
