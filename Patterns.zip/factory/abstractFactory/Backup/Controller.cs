﻿using System;
using AbstractFactory.BaseManagement;

namespace AbstractFactory
{
    public class Controller
    {
        RaceFactory race; // фабрика, отвечающая за создание игровых юнитов. 
        public Controller(RaceFactory race)
        {
            this.race = race;
        }
        /// <summary>
        /// "Игра"
        /// </summary>
        public void PlayGame()
        {
            // Создаем юниты. Процесс создания юнитов не зависит от их расы.
            Producer producer = race.CreateProducer();
            Warrior  warrior  = race.CreateWarrior();
            Shooter  Shooter   = race.CreateShooter();

            // Отдаем им какие-либо команды. Процесс управления юнитами не 
            // зависит от их расы.
            producer.MiningGold();
            warrior.Cast();
            Shooter.Shoot();
        }
    }
}
