﻿using System;

namespace AbstractFactory.Orks
{
    /// <summary>
    /// Класс, описывающий функциональное поведение боевого юнита расы Орки
    /// </summary>
    class OgreMage : AbstractFactory.BaseManagement.Warrior
    {
        public OgreMage()
        {
            Console.WriteLine("Че такое?");
        }

        /// <summary>
        /// Метод, реализующий применение заклинаний огром-магом
        /// </summary>
        public override void Cast()
        {
            Console.WriteLine("А вот кому свежий файербольчик...");
        }

        /// <summary>
        /// Метод, реализующий рукопашную атаку огра-мага
        /// </summary>
        public override void HandToHand()
        {
            Console.WriteLine("Па-абиригись...");
        }
    }
}
