﻿using System;

namespace AbstractFactory.Orks
{
    /// <summary>
    /// Класс, описывающий функциональное поведение рабочего расы Орки.
    /// </summary>
    class Slave : AbstractFactory.BaseManagement.Producer
    {
        public Slave()
        {
            Console.WriteLine("А-а-а... не бейте меня, хозяин!");
        }

        /// <summary>
        /// Метод, реализующий добычу золота рабочим
        /// </summary>
        public override void MiningGold()
        {
            Console.WriteLine("Опять копать...");
        }

        /// <summary>
        /// Метод, реализующий рубку леса рабочим
        /// </summary>
        public override void FellTrees()
        {
            Console.WriteLine("Опять рубить...");
        }

        /// <summary>
        /// Метод, реализующий постройку зданий рабочим
        /// </summary>
        public override void Build()
        {
            Console.WriteLine("Хозяин, я же ничего, кроме землянки, строить не умею...");
        }
    }
}
