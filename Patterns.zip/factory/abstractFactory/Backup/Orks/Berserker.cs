﻿using System;

namespace AbstractFactory.Orks
{
    /// <summary>
    /// Класс, описывающий функциональное поведение стрелка-разведчика расы Орки
    /// </summary>    
    class Berserker : AbstractFactory.BaseManagement.Shooter
    {
        public Berserker()
        {
            Console.WriteLine("Смотри, я наточил свой топор!");
        }

        /// <summary>
        /// Метод, реализующий стрельбу из лука применительно к юниту берсерк
        /// </summary>
        public override void Shoot()
        {
            Console.WriteLine("Лови топор!");
        }

        /// <summary>
        /// Метод, реализующий разведку местности применительно к юниту берсерк
        /// </summary>
        public override void Reconnoitre()
        {
            Console.WriteLine("Куда ты меня послал?!");
        }
    }
}
