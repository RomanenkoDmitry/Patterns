﻿using System;
using AbstractFactory.BaseManagement;

namespace AbstractFactory.Orks
{
    /// <summary>
    /// Класс, описывающий методы создания типовых игровых юнитов
    /// для расы Орки.
    /// </summary>
    class OrksFactory : RaceFactory
    {
        /// <summary>
        /// Создание раба (юнит, производящий ресурсы для расы Орки)
        /// </summary>
        /// <returns>Ссылка на раба, приведенная к абстрактному классу Producer</returns>
        public override Producer CreateProducer()
        {
            return new Slave();
        }

        /// <summary>
        /// Создание берсерка (стрелковый юнит расы Орки)
        /// </summary>
        /// <returns>Ссылка на берсерка, приведенная к абстрактному классу Shooter</returns>
        public override Shooter CreateShooter()
        {
            return new Berserker();
        }

        /// <summary>
        /// Создание огра-мага (боевой юнит расы Орки)
        /// </summary>
        /// <returns>Ссылка на огра-мага, приведенная к абстрактному классу Warrior</returns>
        public override Warrior CreateWarrior()
        {
            return new OgreMage();
        }
    }
}
