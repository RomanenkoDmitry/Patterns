﻿using System;

namespace abstractFactory.FactoryManagment
{
    class Program
    {
		static void Main(string[] args)
		{
			Controller fguitar = new Controller(new Fender.FenderCompany());
			Controller gguitar = new Controller(new Gibson.GibsonCorparation());

			Console.WriteLine("Fender:");
			fguitar.CreateGuitar();

			Console.WriteLine("\nGibson:");
			gguitar.CreateGuitar();

			Console.Read();
		}
	}
}
