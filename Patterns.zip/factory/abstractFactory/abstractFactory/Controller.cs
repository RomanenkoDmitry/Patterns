﻿using System;
using abstractFactory.FactoryManagment;

namespace abstractFactory
{
    public class Controller
    {
        Factory bildguitar;
        public Controller(Factory bildguitar)
        {
            this.bildguitar = bildguitar;
        }
        /// <summary>
        /// "Производство"
        /// </summary>
        public void CreateGuitar()
        {
            Acoustic acoustic = bildguitar.CreateAcoustic();
            Electric electric = bildguitar.CreateElectric();
            Strings strings = bildguitar.CreateStrings();

            acoustic.DeckForm();
            electric.WoodChoice();
            strings.Size();
        }
    }
}